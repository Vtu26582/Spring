package edu.SampleMavenSpringCore;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {   
        // Create Spring container with your config class
        AnnotationConfigApplicationContext container = 
            new AnnotationConfigApplicationContext(config.class);
            
        System.out.println("Hello World!");
        
        // Get Book bean from container
        Book b = container.getBean(Book.class);
        System.out.println(b);
        
        // Close the container
        container.close();
    }
}