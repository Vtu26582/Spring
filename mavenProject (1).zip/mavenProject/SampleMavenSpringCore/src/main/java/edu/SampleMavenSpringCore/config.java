package edu.SampleMavenSpringCore;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages= {"edu.SampleMavenSpringCore"})
public class config {

}
