package edu.SampleMavenSpringCore;

import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;

@Component
public class Book {
    
    @Value("MyBook")
    private String bookName;
    
    public Book() {
        super();
        // Don't set bookName here, it will be set by @Value
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }
    
    @Override
    public String toString() {
        return "Book [bookName=" + bookName + "]";
    }
}