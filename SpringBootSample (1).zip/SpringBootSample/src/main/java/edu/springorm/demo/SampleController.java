package edu.springorm.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleController {
    
	@GetMapping("/home")
	public String show() {
		return "Welcome to SpringBoot";
	}

}
